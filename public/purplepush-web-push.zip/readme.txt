=== PurplePush - Web Push Notifications ===
Contributors: PurplePush
Tags: push notifications, web push, browser notifications, marketing, engagement
Requires at least: 5.6
Tested up to: 6.6
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connect your WordPress website to PurplePush to send real-time Web Push Notifications to your website visitors across Desktop, Android, and iOS devices.

== Description ==

**PurplePush** allows you to engage your site visitors with instant, high-converting web push notifications directly to their devices — even when they are not actively browsing your site.

### Key Features:
* **One-Click Integration**: Connect your WordPress site to your PurplePush dashboard using your unique Tracking ID and Server URL.
* **Automated Web SDK Injection**: Automatically injects the lightweight tracking script into the `<head>` of your website.
* **Virtual Service Worker**: Serves `sw.js` directly at your root domain (`/sw.js`) dynamically via WordPress rewrite rules, eliminating the need for manual FTP uploads.
* **Zero Performance Overhead**: Asynchronous loading ensures your page load speeds and Core Web Vitals remain completely unaffected.
* **WP-Admin Diagnostics**: Built-in status check in WP-Admin lets you verify tracking ID, server connection, and service worker availability in real-time.

== Installation ==

1. Upload the `wpextension` folder to the `/wp-content/plugins/` directory, or zip the folder and upload via **WordPress Admin -> Plugins -> Add New -> Upload Plugin**.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to **Settings -> PurplePush**.
4. Enter your **PurplePush Server URL** (e.g., `https://your-purplepush-domain.com`) and your **Site Tracking ID** (found in your PurplePush dashboard under Site Settings).
5. Click **Save Changes**.

== Frequently Asked Questions ==

= Do I need to upload `sw.js` manually to my web root? =
No! The plugin automatically sets up a virtual rewrite rule so browser requests to `https://yourdomain.com/sw.js` are served automatically with the correct `Service-Worker-Allowed: /` header.

= Where do I find my Site Tracking ID? =
Log into your PurplePush dashboard, navigate to **Sites**, select your website, and copy the Tracking ID provided in the installation panel.

== Changelog ==

= 1.0.0 =
* Initial release of the official PurplePush WordPress extension.
