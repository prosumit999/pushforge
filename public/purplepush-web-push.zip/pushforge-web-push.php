<?php
/**
 * Plugin Name: PurplePush - Web Push Notifications
 * Plugin URI:  https://github.com/prosumit999/pushforge
 * Description: Connect your WordPress website to PurplePush to send instant web push notifications, collect subscribers, build segments, and track click analytics.
 * Version:     1.0.0
 * Author:      PurplePush / PushForge Team
 * Author URI:  https://github.com/prosumit999
 * License:     GPLv2 or later
 * Text Domain: purplepush-web-push
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

define('PURPLEPUSH_VERSION', '1.0.0');
define('PURPLEPUSH_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('PURPLEPUSH_PLUGIN_URL', plugin_dir_url(__FILE__));

class PurplePush_Plugin {

    public function __construct() {
        // Admin Settings Page
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));

        // Script Injection into <head>
        add_action('wp_head', array($this, 'inject_tracking_script'));

        // Service Worker Routing (Serves sw.js directly at domain root)
        add_action('init', array($this, 'add_sw_rewrite_rule'));
        add_filter('query_vars', array($this, 'add_sw_query_var'));
        add_action('template_redirect', array($this, 'handle_sw_request'));

        // Enqueue Admin Styles
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));

        // Plugin Activation & Deactivation Hooks
        register_activation_hook(__FILE__, array($this, 'activate_plugin'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate_plugin'));
    }

    public function activate_plugin() {
        $this->add_sw_rewrite_rule();
        flush_rewrite_rules();
    }

    public function deactivate_plugin() {
        flush_rewrite_rules();
    }

    public function add_sw_rewrite_rule() {
        add_rewrite_rule('^sw\.js$', 'index.php?purplepush_sw=1', 'top');
    }

    public function add_sw_query_var($vars) {
        $vars[] = 'purplepush_sw';
        return $vars;
    }

    public function handle_sw_request() {
        if (get_query_var('purplepush_sw') == 1) {
            $tracking_id = get_option('purplepush_tracking_id', '');
            $server_url = rtrim(get_option('purplepush_server_url', 'http://localhost:5000'), '/');

            header('Content-Type: application/javascript; charset=utf-8');
            header('Service-Worker-Allowed: /');
            header('Cache-Control: no-cache, no-store, must-revalidate');

            echo "// PurplePush WordPress Service Worker v1.0\n";
            echo "// Tracking ID: " . esc_js($tracking_id) . "\n\n";
            echo "self.addEventListener('push', function (event) {\n";
            echo "  var data = {};\n";
            echo "  if (event.data) {\n";
            echo "    try { data = event.data.json(); } catch (e) { data = { title: 'Notification', body: event.data.text() }; }\n";
            echo "  } else { data = { title: 'Push Notification', body: 'New Update' }; }\n";
            echo "  var title = data.title || 'Notification';\n";
            echo "  var isSticky = Boolean(data.requireInteraction || data.sticky);\n";
            echo "  var options = {\n";
            echo "    body: data.body || '',\n";
            echo "    icon: data.icon || '/favicon.ico',\n";
            echo "    badge: data.badge || '/favicon.ico',\n";
            echo "    image: data.image || null,\n";
            echo "    requireInteraction: isSticky,\n";
            echo "    data: {\n";
            echo "      url: data.clickUrl || data.url || '/',\n";
            echo "      campaignId: data.campaignId || null,\n";
            echo "      trackingId: '" . esc_js($tracking_id) . "',\n";
            echo "      host: '" . esc_js($server_url) . "'\n";
            echo "    },\n";
            echo "    actions: data.actionButtons || []\n";
            echo "  };\n";
            echo "  event.waitUntil(self.registration.showNotification(title, options));\n";
            echo "});\n\n";

            echo "self.addEventListener('notificationclick', function (event) {\n";
            echo "  event.notification.close();\n";
            echo "  var notificationData = event.notification.data || {};\n";
            echo "  var targetUrl = notificationData.url || '/';\n";
            echo "  var targetHost = notificationData.host || '" . esc_js($server_url) . "';\n";
            echo "  var trackingKey = notificationData.trackingId || '" . esc_js($tracking_id) . "';\n";
            echo "  if (trackingKey) {\n";
            echo "    fetch(targetHost + '/api/v1/public/click', {\n";
            echo "      method: 'POST',\n";
            echo "      headers: { 'Content-Type': 'application/json', 'x-site-key': trackingKey },\n";
            echo "      body: JSON.stringify({\n";
            echo "        eventType: 'click',\n";
            echo "        trackingId: trackingKey,\n";
            echo "        campaignId: notificationData.campaignId || null,\n";
            echo "        url: targetUrl,\n";
            echo "        timestamp: new Date().toISOString()\n";
            echo "      })\n";
            echo "    }).catch(function (err) { console.warn('PurplePush SW Telemetry:', err); });\n";
            echo "  }\n";
            echo "  event.waitUntil(clients.openWindow(targetUrl));\n";
            echo "});\n";

            exit;
        }
    }

    public function inject_tracking_script() {
        $enabled = get_option('purplepush_enable_sdk', '1');
        if ($enabled !== '1') return;

        $site_url = get_site_url();
        $site_domain = parse_url($site_url, PHP_URL_HOST);
        $tracking_id = get_option('purplepush_tracking_id', '');
        if (empty($tracking_id)) {
            $tracking_id = $site_domain;
        }

        $server_url = rtrim(get_option('purplepush_server_url', 'http://localhost:5000'), '/');

        echo "\n<!-- PurplePush Web Push Notifications SDK -->\n";
        echo '<script src="' . esc_url($server_url . '/sdk.js') . '" data-site-key="' . esc_attr($tracking_id) . '" data-tracking-id="' . esc_attr($tracking_id) . '" data-host="' . esc_url($server_url) . '" async></script>' . "\n";
        echo "<!-- End PurplePush SDK -->\n\n";
    }

    public function add_admin_menu() {
        add_menu_page(
            'PurplePush Settings',
            'PurplePush',
            'manage_options',
            'purplepush-settings',
            array($this, 'render_admin_page'),
            PURPLEPUSH_PLUGIN_URL . 'assets/icon.png',
            80
        );
    }

    public function register_settings() {
        register_setting('purplepush_options_group', 'purplepush_server_url');
        register_setting('purplepush_options_group', 'purplepush_tracking_id');
        register_setting('purplepush_options_group', 'purplepush_enable_sdk');
    }

    public function enqueue_admin_assets($hook) {
        if ($hook !== 'toplevel_page_purplepush-settings') return;
        wp_enqueue_style('purplepush-admin-css', PURPLEPUSH_PLUGIN_URL . 'assets/admin.css', array(), PURPLEPUSH_VERSION);
    }

    public function render_admin_page() {
        $server_url = get_option('purplepush_server_url', 'http://localhost:5000');
        $tracking_id = get_option('purplepush_tracking_id', '');
        $enable_sdk = get_option('purplepush_enable_sdk', '1');
        $site_url = get_site_url();
        $site_domain = parse_url($site_url, PHP_URL_HOST);
        $site_name = get_bloginfo('name');
        $site_logo_url = function_exists('get_site_icon_url') ? get_site_icon_url(128) : '';
        $sw_url = rtrim($site_url, '/') . '/sw.js';
        $plugin_icon_url = PURPLEPUSH_PLUGIN_URL . 'assets/icon.png';
        ?>
        <div class="wrap purplepush-admin-wrap">
            <div class="purplepush-admin-header">
                <div class="purplepush-brand">
                    <div class="purplepush-logo-icon-wrap">
                        <img src="<?php echo esc_url($plugin_icon_url); ?>" alt="PurplePush Logo" style="width:26px;height:26px;object-fit:contain;filter:brightness(0) invert(1);" />
                    </div>
                    <div>
                        <h2>PurplePush Web Push Integration</h2>
                        <p>Automatic Web Push Notifications for WordPress</p>
                    </div>
                </div>
                <div class="purplepush-header-badge">
                    <?php if (!empty($tracking_id)) : ?>
                        <span class="badge badge-active">
                            <span style="width:7px;height:7px;border-radius:50%;background:#10b981;display:inline-block;"></span>
                            Tracking Active
                        </span>
                    <?php else : ?>
                        <span class="badge badge-warning">
                            <span style="width:7px;height:7px;border-radius:50%;background:#f59e0b;display:inline-block;"></span>
                            Setup Required
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (isset($_GET['settings-updated'])) : ?>
                <div class="notice notice-success is-dismissible">
                    <p><strong>PurplePush settings updated successfully!</strong> Service Worker route active at <code><?php echo esc_html($sw_url); ?></code></p>
                </div>
            <?php endif; ?>

            <div class="purplepush-admin-grid">
                <div class="purplepush-card main-config-card">
                    <h3>Connection & Server Configuration</h3>
                    <form method="post" action="options.php">
                        <?php settings_fields('purplepush_options_group'); ?>
                        <?php do_settings_sections('purplepush_options_group'); ?>

                        <div class="form-field">
                            <label for="purplepush_server_url">PurplePush Server URL</label>
                            <input type="url" id="purplepush_server_url" name="purplepush_server_url" value="<?php echo esc_attr($server_url); ?>" placeholder="https://your-pushforge-server.com" required class="regular-text" />
                            <p class="description">URL of your deployed PurplePush server (e.g. <code>http://localhost:5000</code> or live backend domain).</p>
                        </div>

                        <div class="form-field">
                            <label for="purplepush_tracking_id">Website Tracking ID / Site Key *</label>
                            <input type="text" id="purplepush_tracking_id" name="purplepush_tracking_id" value="<?php echo esc_attr($tracking_id); ?>" placeholder="Copy Tracking ID from PurplePush Dashboard -> Sites" required class="regular-text" />
                            <p class="description">Copy your website's Tracking ID from your PurplePush Dashboard under <strong>Sites</strong>.</p>
                        </div>

                        <div class="form-field checkbox-field">
                            <label for="purplepush_enable_sdk">
                                <input type="checkbox" id="purplepush_enable_sdk" name="purplepush_enable_sdk" value="1" <?php checked($enable_sdk, '1'); ?> />
                                Automatically inject Web Push SDK script into <code>&lt;head&gt;</code> of all pages
                            </label>
                        </div>

                        <div class="submit-row">
                            <button type="submit" name="submit" id="submit" class="button button-primary purplepush-save-btn">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path>
                                    <polyline points="17 21 17 13 7 13 7 21"></polyline>
                                    <polyline points="7 3 7 8 15 8"></polyline>
                                </svg>
                                <span>Save PurplePush Settings</span>
                            </button>
                        </div>
                    </form>
                </div>

                <div class="purplepush-card sidebar-info-card">
                    <h3>Integration Diagnostics</h3>
                    <ul class="diag-list">
                        <li>
                            <span class="diag-label">SDK Script Tag</span>
                            <span class="diag-val"><?php echo $enable_sdk == '1' && !empty($tracking_id) ? '<strong style="color:#059669;">Active in &lt;head&gt;</strong>' : '<span style="color:#dc2626;">Disabled / Pending Key</span>'; ?></span>
                        </li>
                        <li>
                            <span class="diag-label">Service Worker Endpoint</span>
                            <a href="<?php echo esc_url($sw_url); ?>" target="_blank" class="diag-link"><?php echo esc_html($sw_url); ?></a>
                        </li>
                        <li>
                            <span class="diag-label">Site Domain & Website Logo</span>
                            <div class="purplepush-site-logo-card">
                                <?php if (!empty($site_logo_url)) : ?>
                                    <img src="<?php echo esc_url($site_logo_url); ?>" alt="<?php echo esc_attr($site_name); ?>" class="purplepush-site-logo-img" />
                                <?php else : ?>
                                    <div class="purplepush-site-logo-fallback">
                                        <?php echo esc_html(strtoupper(substr($site_name ? $site_name : $site_domain, 0, 1))); ?>
                                    </div>
                                <?php endif; ?>
                                <div>
                                    <strong style="display:block;font-size:0.88rem;color:#0f172a;"><?php echo esc_html($site_name ? $site_name : 'WordPress Site'); ?></strong>
                                    <code><?php echo esc_html($site_domain); ?></code>
                                </div>
                            </div>
                        </li>
                    </ul>

                    <div class="setup-guide-box">
                        <h4>3-Step Connection Guide</h4>
                        <ol>
                            <li>Log in to your <strong>PurplePush Dashboard</strong>.</li>
                            <li>Go to <strong>Sites</strong> -> Add your website domain (<code><?php echo esc_html(parse_url($site_url, PHP_URL_HOST)); ?></code>).</li>
                            <li>Copy the <strong>Tracking ID</strong> and paste it into the field on the left!</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
}

new PurplePush_Plugin();
